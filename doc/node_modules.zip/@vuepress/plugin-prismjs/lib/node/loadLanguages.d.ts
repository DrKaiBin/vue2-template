export declare const loadLanguages: (languages: string[]) => void;
