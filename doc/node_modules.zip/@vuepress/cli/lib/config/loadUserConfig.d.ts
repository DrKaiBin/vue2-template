import type { UserConfig } from './types';
/**
 * Load user config file
 */
export declare const loadUserConfig: (userConfigPath?: string | undefined) => Promise<UserConfig>;
