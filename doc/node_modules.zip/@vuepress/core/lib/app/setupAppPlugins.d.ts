import type { App } from '../types';
/**
 * Setup plugins for vuepress app
 */
export declare const setupAppPlugins: (app: App) => void;
