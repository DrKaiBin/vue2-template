import type * as Token from 'markdown-it/lib/token';
import type { MarkdownHeader } from '../types';
/**
 * Resolve headers from markdown-it tokens
 */
export declare const resolveHeadersFromTokens: (tokens: Token[], { level, allowHtml, escapeText, slugify, format, }: {
    level: number[];
    allowHtml: boolean;
    escapeText: boolean;
    slugify: (str: string) => string;
    format?: ((str: string) => string) | undefined;
}) => MarkdownHeader[];
