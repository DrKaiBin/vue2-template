import type { PluginWithOptions } from 'markdown-it';
export interface ExtractHeadersPluginOptions {
    /**
     * Heading level that going to be extracted to the `env`
     *
     * Should be a subset of markdown-it-anchor's `level` option
     * to ensure the link is existed
     */
    level?: number[];
    /**
     * A custom slugify function
     *
     * Should use the same slugify function with markdown-it-anchor
     * to ensure the link is matched
     */
    slugify?: (str: string) => string;
    /**
     * A function for formatting headers
     */
    format?: (str: string) => string;
}
/**
 * Extracting markdown headers to env
 *
 * Would be used for generating sidebar nav and toc
 */
export declare const extractHeadersPlugin: PluginWithOptions<ExtractHeadersPluginOptions>;
