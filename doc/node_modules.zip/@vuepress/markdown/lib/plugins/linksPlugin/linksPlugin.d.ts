import type { PluginWithOptions } from 'markdown-it';
export interface LinksPluginOptions {
    /**
     * Tag for internal links
     *
     * @default 'RouterLink'
     */
    internalTag?: 'a' | 'RouterLink';
    /**
     * Additional attributes for external links
     *
     * @default
     * ```js
     * ({
     *   target: '_blank',
     *   rel: 'noopener noreferrer',
     * })
     * ```
     */
    externalAttrs?: Record<string, string>;
}
/**
 * Process links in markdown file
 *
 * - internal links: convert them into `<RouterLink>`
 * - external links: add extra attrs and external icon
 */
export declare const linksPlugin: PluginWithOptions<LinksPluginOptions>;
