import type { MarkdownEnv } from '../../types';
import type { ImportCodeTokenMeta } from './types';
export declare const resolveImportCode: ({ importPath, lineStart, lineEnd }: ImportCodeTokenMeta, { filePath }: MarkdownEnv) => {
    importFilePath: string | null;
    importCode: string;
};
