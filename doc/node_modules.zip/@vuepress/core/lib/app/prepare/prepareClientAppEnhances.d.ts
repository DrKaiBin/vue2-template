import type { App } from '../../types';
/**
 * Generate client app enhances temp file
 */
export declare const prepareClientAppEnhances: (app: App) => Promise<void>;
