export declare const resolveRoutePathFromUrl: (url: string, base?: string) => string;
