import { mediumZoomPlugin } from './mediumZoomPlugin';
export * from './mediumZoomPlugin';
export default mediumZoomPlugin;
