/**
 * Ensure a url string to have leading slash /
 */
export declare const ensureLeadingSlash: (str: string) => string;
