import '../styles/vars.css';
import '../styles/nprogress.css';
export declare const useNprogress: () => void;
