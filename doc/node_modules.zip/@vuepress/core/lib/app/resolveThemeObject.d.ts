import type { App, ThemeConfig, ThemeObject } from '../types';
/**
 * Resolve a theme object according to the theme name
 */
export declare const resolveThemeObject: (app: App, theme: string, themeConfig: ThemeConfig) => ThemeObject;
