import type { App } from '../types';
/**
 * Resolve page rendered html file path
 */
export declare const resolvePageHtmlInfo: ({ app, path: pagePath, }: {
    app: App;
    path: string;
}) => {
    htmlFilePath: string;
    htmlFilePathRelative: string;
};
