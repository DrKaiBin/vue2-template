export declare const scrollToTop: () => void;
