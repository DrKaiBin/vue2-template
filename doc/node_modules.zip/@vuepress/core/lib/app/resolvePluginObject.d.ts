import type { App, Plugin, PluginObject, PluginOptions } from '../types';
/**
 * Resolve a plugin object according to name / path / module and config
 */
export declare const resolvePluginObject: <T extends PluginOptions = PluginOptions, U extends PluginObject = PluginObject>(app: App, plugin: string | Plugin<T, U>, pluginConfig?: Partial<T>) => U;
