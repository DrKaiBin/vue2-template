import type { AppDir, AppDirFunction, AppOptions } from '../types';
/**
 * Create directory util function
 */
export declare const createAppDirFunction: (baseDir: string) => AppDirFunction;
/**
 * Resolve directory utils for vuepress app
 */
export declare const resolveAppDir: (options: AppOptions) => AppDir;
