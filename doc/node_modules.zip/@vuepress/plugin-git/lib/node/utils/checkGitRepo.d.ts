/**
 * Check if the git repo is valid
 */
export declare const checkGitRepo: (cwd: string) => boolean;
