export interface ImportCodeTokenMeta {
    importPath: string;
    lineStart: number;
    lineEnd?: number;
}
