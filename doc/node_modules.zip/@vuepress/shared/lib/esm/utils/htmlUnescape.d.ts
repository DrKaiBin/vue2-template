/**
 * Unescape html chars
 */
export declare const htmlUnescape: (str: string) => string;
