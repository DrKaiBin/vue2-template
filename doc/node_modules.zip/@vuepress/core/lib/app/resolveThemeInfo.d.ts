import type { App, ThemeConfig, ThemeInfo } from '../types';
/**
 * Resolve theme info and its parent theme info
 */
export declare const resolveThemeInfo: (app: App, theme: string, themeConfig: ThemeConfig) => ThemeInfo;
