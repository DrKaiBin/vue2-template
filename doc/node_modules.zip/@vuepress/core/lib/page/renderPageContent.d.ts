import type { MarkdownHeader, MarkdownLink } from '@vuepress/markdown';
import type { App, PageFrontmatter } from '../types';
/**
 * Render page content and extract related info
 */
export declare const renderPageContent: ({ app, content, frontmatter, filePath, filePathRelative, }: {
    app: App;
    content: string;
    frontmatter: PageFrontmatter;
    filePath: string | null;
    filePathRelative: string | null;
}) => Promise<{
    contentRendered: string;
    deps: string[];
    headers: MarkdownHeader[];
    hoistedTags: string[];
    links: MarkdownLink[];
    title: string;
}>;
