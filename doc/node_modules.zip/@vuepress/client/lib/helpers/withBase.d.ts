/**
 * Prefix url with site base
 */
export declare const withBase: (url: string) => string;
