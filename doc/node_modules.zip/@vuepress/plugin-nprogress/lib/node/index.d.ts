import { nprogressPlugin } from './nprogressPlugin';
export * from './nprogressPlugin';
export default nprogressPlugin;
