import type { ComponentOptions } from 'vue'

declare module '@internal/clientAppRootComponents' {
  export const clientAppRootComponents: ComponentOptions[]
}
