import type { App } from '../types';
/**
 * Resolve page data file path
 */
export declare const resolvePageDataInfo: ({ app, htmlFilePathRelative, key, }: {
    app: App;
    htmlFilePathRelative: string;
    key: string;
}) => {
    dataFilePath: string;
    dataFilePathRelative: string;
    dataFileChunkName: string;
};
