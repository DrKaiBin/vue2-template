/**
 * Resolve version of vuepress app
 */
export declare const resolveAppVersion: () => string;
