import { containerPlugin } from './containerPlugin';
export * from './containerPlugin';
export default containerPlugin;
