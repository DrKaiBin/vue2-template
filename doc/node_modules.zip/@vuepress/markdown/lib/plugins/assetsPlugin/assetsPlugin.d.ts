import type { PluginWithOptions } from 'markdown-it';
export interface AssetsPluginOptions {
    /**
     * Prefix to add to relative assets links
     */
    relativePathPrefix?: string;
}
/**
 * Plugin to handle assets links
 */
export declare const assetsPlugin: PluginWithOptions<AssetsPluginOptions>;
