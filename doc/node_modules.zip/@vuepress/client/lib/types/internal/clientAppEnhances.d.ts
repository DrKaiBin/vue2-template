import type { ClientAppEnhance } from '../clientAppEnhance'

declare module '@internal/clientAppEnhances' {
  export const clientAppEnhances: ClientAppEnhance[]
}
