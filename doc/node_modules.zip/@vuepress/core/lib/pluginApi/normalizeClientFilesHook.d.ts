import type { ClientFilesHook } from '../types';
/**
 * Normalize hook for client files
 */
export declare const normalizeClientFilesHook: (hook: ClientFilesHook['exposed']) => ClientFilesHook['normalized'];
