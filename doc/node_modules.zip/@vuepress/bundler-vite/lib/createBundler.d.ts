import type { CreateBundlerFunction } from '@vuepress/core';
import type { ViteBundlerOptions } from './types';
export declare const createBundler: CreateBundlerFunction<ViteBundlerOptions>;
