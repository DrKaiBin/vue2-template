import type { Plugin } from '@vuepress/core';
import type { ZoomOptions } from 'medium-zoom';
export interface MediumZoomPluginOptions {
    selector: string;
    zoomOptions?: ZoomOptions;
    delay?: number;
}
export declare const mediumZoomPlugin: Plugin<MediumZoomPluginOptions>;
export default mediumZoomPlugin;
