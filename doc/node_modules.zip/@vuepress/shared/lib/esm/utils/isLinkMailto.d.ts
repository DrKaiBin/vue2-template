/**
 * Determine a link is a mailto: address or not
 */
export declare const isLinkMailto: (link: string) => boolean;
