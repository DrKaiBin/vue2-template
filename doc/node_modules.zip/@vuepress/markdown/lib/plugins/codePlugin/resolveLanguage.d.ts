import type { HighlightLanguage } from './languages';
/**
 * Resolve language for highlight from token info
 */
export declare const resolveLanguage: (info: string) => HighlightLanguage;
