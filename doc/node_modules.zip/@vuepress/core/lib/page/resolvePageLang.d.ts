import type { App, PageFrontmatter } from '../types';
/**
 * Resolve language of page
 */
export declare const resolvePageLang: ({ app, frontmatter, pathLocale, }: {
    app: App;
    frontmatter: PageFrontmatter;
    pathLocale: string;
}) => string;
