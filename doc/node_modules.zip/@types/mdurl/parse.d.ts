import { Url } from './';

declare function parse(input: string, slashesDenoteHost?: boolean): Url;

export = parse;
