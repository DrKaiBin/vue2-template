import type { App } from '../../types';
/**
 * Generate layout components temp file
 */
export declare const prepareLayoutComponents: (app: App) => Promise<void>;
