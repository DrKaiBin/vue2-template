import type { Plugin } from '@vuepress/core';
export interface ActiveHeaderLinksPluginOptions {
    headerLinkSelector?: string;
    headerAnchorSelector?: string;
    delay?: number;
    offset?: number;
}
export declare const activeHeaderLinksPlugin: Plugin<ActiveHeaderLinksPluginOptions>;
