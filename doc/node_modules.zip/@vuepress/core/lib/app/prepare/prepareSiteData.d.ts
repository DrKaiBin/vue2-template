import type { App } from '../../types';
/**
 * Generate site data temp file
 */
export declare const prepareSiteData: (app: App) => Promise<void>;
