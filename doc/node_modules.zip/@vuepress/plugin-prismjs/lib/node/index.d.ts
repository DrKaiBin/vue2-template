import { prismjsPlugin } from './prismjsPlugin';
export * from './loadLanguages';
export * from './prismjsPlugin';
export * from './resolveHighlighter';
export default prismjsPlugin;
