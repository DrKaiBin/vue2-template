import type { App } from 'vue';
import type { Router } from 'vue-router';
import type { PageData, PageDataRef, PageFrontmatter, PageFrontmatterRef, PageHead, PageHeadRef, PageHeadTitle, PageHeadTitleRef, PageLang, PageLangRef, RouteLocale, RouteLocaleRef, SiteData, SiteDataRef, SiteLocaleData, SiteLocaleDataRef } from './composables';
import { withBase } from './helpers';
/**
 * Vuepress client global computed
 */
export interface GlobalComputed {
    pageData: PageDataRef;
    pageFrontmatter: PageFrontmatterRef;
    pageHead: PageHeadRef;
    pageHeadTitle: PageHeadTitleRef;
    pageLang: PageLangRef;
    routeLocale: RouteLocaleRef;
    siteData: SiteDataRef;
    siteLocaleData: SiteLocaleDataRef;
}
/**
 * Create and provide global computed
 */
export declare const setupGlobalComputed: (app: App, router: Router) => GlobalComputed;
declare module '@vue/runtime-core' {
    interface ComponentCustomProperties {
        $frontmatter: PageFrontmatter;
        $head: PageHead;
        $headTitle: PageHeadTitle;
        $lang: PageLang;
        $page: PageData;
        $routeLocale: RouteLocale;
        $site: SiteData;
        $siteLocale: SiteLocaleData;
        $withBase: typeof withBase;
    }
}
