import type { PluginSimple } from 'markdown-it';
/**
 * Replacing the default htmlBlock rule to allow using custom components
 * in markdown
 */
export declare const customComponentPlugin: PluginSimple;
