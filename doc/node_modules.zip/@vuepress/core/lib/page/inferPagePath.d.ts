import type { App } from '../types';
/**
 * Infer page path according to file path
 */
export declare const inferPagePath: ({ app, filePathRelative, }: {
    app: App;
    filePathRelative: string | null;
}) => {
    pathInferred: string | null;
    pathLocale: string;
};
