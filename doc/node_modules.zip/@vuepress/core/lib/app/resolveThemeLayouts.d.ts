import type { ThemeObject } from '../types';
/**
 * Resolve layouts from `layouts` option
 */
export declare const resolveThemeLayouts: (layouts?: ThemeObject['layouts']) => Record<string, string>;
