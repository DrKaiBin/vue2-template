export declare type ClientAppSetup = () => void;
