import type { Router } from 'vue-router';
export interface UseActiveHeaderLinksOptions {
    headerLinkSelector: string;
    headerAnchorSelector: string;
    delay: number;
    offset?: number;
}
export declare const useActiveHeaderLinks: ({ headerLinkSelector, headerAnchorSelector, delay, offset, }: UseActiveHeaderLinksOptions) => void;
/**
 * Call `router.replace()` and do not trigger `scrollBehavior`
 */
export declare const replaceWithoutScrollBehavior: (router: Router, to: import("vue-router").RouteLocationRaw) => Promise<void>;
