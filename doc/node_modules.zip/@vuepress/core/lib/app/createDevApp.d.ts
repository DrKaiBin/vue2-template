import type { AppConfig, DevApp } from '../types';
/**
 * Create vuepress dev app
 */
export declare const createDevApp: (config: AppConfig) => DevApp;
