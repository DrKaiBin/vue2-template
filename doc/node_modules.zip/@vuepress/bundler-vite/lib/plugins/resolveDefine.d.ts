import type { App } from '@vuepress/core';
import type { UserConfig } from 'vite';
export declare const resolveDefine: ({ app, isServer, }: {
    app: App;
    isServer: boolean;
}) => Promise<UserConfig['define']>;
