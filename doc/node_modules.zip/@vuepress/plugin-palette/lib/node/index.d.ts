import { palettePlugin } from './palettePlugin';
export * from './palettePlugin';
export * from './preparePaletteFile';
export * from './prepareStyleFile';
export * from './presetOptions';
export default palettePlugin;
