import type { HeadConfig } from '@vuepress/shared';
import type { ComputedRef, InjectionKey } from 'vue';
/**
 * Page head config, which would be used for generate html tags in `<head>`
 */
export declare type PageHead = HeadConfig[];
/**
 * Ref wrapper of `PageHead`
 */
export declare type PageHeadRef = ComputedRef<PageHead>;
/**
 * Injection key for page head
 */
export declare const pageHeadSymbol: InjectionKey<PageHeadRef>;
/**
 * Returns the ref of the head config of current page
 */
export declare const usePageHead: () => PageHeadRef;
