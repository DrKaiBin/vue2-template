import type { HeadConfig } from '../types';
/**
 * Dedupe head config with identifier
 *
 * Items that appear earlier have higher priority
 */
export declare const dedupeHead: (head: HeadConfig[]) => HeadConfig[];
