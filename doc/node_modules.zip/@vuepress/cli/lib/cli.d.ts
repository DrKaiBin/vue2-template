import type { AppConfig } from '@vuepress/core';
/**
 * Vuepress cli
 */
export declare const cli: (defaultAppConfig?: Partial<AppConfig>) => void;
