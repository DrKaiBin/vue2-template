/**
 * Check if a value is plain object, with generic type support
 */
export declare const isPlainObject: <T extends Record<any, any> = Record<any, any>>(val: unknown) => val is T;
