import { externalLinkIconPlugin } from './externalLinkIconPlugin';
export * from './externalLinkIconPlugin';
export default externalLinkIconPlugin;
