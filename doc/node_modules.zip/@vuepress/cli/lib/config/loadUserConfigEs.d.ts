import type { UserConfigLoader } from './types';
/**
 * Load es config file
 */
export declare const loadUserConfigEs: UserConfigLoader;
