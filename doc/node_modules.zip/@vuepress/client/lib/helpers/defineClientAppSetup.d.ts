import type { ClientAppSetup } from '../types';
export declare const defineClientAppSetup: (clientAppSetup: ClientAppSetup) => ClientAppSetup;
