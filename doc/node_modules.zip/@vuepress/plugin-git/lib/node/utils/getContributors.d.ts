import type { GitContributor } from '../types';
export declare const getContributors: (filePath: string, cwd: string) => Promise<GitContributor[]>;
