import type { PluginWithOptions } from 'markdown-it';
export interface TocPluginOptions {
    /**
     * The pattern serving as the TOC placeholder in your markdown
     */
    pattern?: RegExp;
    /**
     * A custom slugify function
     *
     * Should use the same slugify function with markdown-it-anchor
     * to ensure the link is matched
     */
    slugify?: (str: string) => string;
    /**
     * A function for formatting headers
     */
    format?: (str: string) => string;
    /**
     * Heading level that going to be extracted to the `env`
     *
     * Should be a subset of markdown-it-anchor's `level` option
     * to ensure the link is existed
     */
    level?: number[];
    /**
     * HTML tag of container
     */
    containerTag?: string;
    /**
     * The class for container
     */
    containerClass?: string;
    /**
     * HTML tag of list
     */
    listTag?: 'ul' | 'ol';
    /**
     * The class for list
     */
    listClass?: string;
    /**
     * The class for the <li> tag
     */
    itemClass?: string;
    /**
     * The tag for the link inside <li>
     */
    linkTag?: 'a' | 'RouterLink';
    /**
     * The class for the link tag inside <li>
     */
    linkClass?: string;
}
/**
 * Generate table of contents
 *
 * Forked and modified from markdown-it-toc-done-right:
 *
 * - Allows `html_inline` tags in headings to support vue components
 * - Allows render `<RouterLink>` instead of `<a>` for links
 * - Code refactor and optimizations
 *
 * @see https://github.com/nagaozen/markdown-it-toc-done-right
 */
export declare const tocPlugin: PluginWithOptions<TocPluginOptions>;
