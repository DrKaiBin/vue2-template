import type { ReturnObjectHook } from '../types';
/**
 * Normalize hook that returns an object
 */
export declare const normalizeReturnObjectHook: (hook: ReturnObjectHook['exposed']) => ReturnObjectHook['normalized'];
