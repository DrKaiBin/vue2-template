import type { PageFrontmatter } from '../types';
/**
 * Resolve page date according to frontmatter or file path
 *
 * It will be resolved as 'yyyy-MM-dd' format
 */
export declare const resolvePageDate: ({ frontmatter, filePathRelative, }: {
    frontmatter: PageFrontmatter;
    filePathRelative: string | null;
}) => string;
