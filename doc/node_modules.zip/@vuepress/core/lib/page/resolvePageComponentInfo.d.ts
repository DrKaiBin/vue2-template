import type { App } from '../types';
/**
 * Resolve page component and related info
 */
export declare const resolvePageComponentInfo: ({ app, hoistedTags, htmlFilePathRelative, key, }: {
    app: App;
    hoistedTags: string[];
    htmlFilePathRelative: string;
    key: string;
}) => Promise<{
    componentFilePath: string;
    componentFilePathRelative: string;
    componentFileChunkName: string;
}>;
