export declare const slugify: (str: string) => string;
