import type { PluginApi } from '../types';
export declare const createPluginApiHooks: () => PluginApi['hooks'];
