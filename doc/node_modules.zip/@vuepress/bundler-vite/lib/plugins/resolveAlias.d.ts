import type { App } from '@vuepress/core';
import type { AliasOptions } from 'vite';
export declare const resolveAlias: ({ app, }: {
    app: App;
}) => Promise<AliasOptions>;
