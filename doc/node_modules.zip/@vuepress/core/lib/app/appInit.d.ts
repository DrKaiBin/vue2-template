import type { App } from '../types';
/**
 * Initialize a vuepress app
 *
 * Plugins should be used before initialization.
 */
export declare const appInit: (app: App) => Promise<void>;
