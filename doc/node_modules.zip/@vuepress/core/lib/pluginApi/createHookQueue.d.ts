import type { HookQueue } from '../types';
/**
 * Create hook queue for plugin system
 */
export declare const createHookQueue: <T extends keyof import("../types").Hooks>(name: T) => HookQueue<T>;
