import type { UserConfig } from '../../config';
/**
 * Load user config file and resolve its dependencies
 */
export declare const resolveDevUserConfig: (userConfigPath?: string | undefined) => Promise<{
    userConfig: UserConfig;
    userConfigDeps: string[];
}>;
