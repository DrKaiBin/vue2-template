import type { App } from '../../types';
/**
 * Generate routes temp file
 */
export declare const preparePagesRoutes: (app: App) => Promise<void>;
