import type { App, Page } from '../../types';
/**
 * Generate page data temp file of a single page
 */
export declare const preparePageData: (app: App, page: Page) => Promise<void>;
