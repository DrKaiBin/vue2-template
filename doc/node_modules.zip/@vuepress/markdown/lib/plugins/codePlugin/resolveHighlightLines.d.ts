export declare type HighlightLinesRange = [number, number];
/**
 * Resolve highlight-lines ranges from token info
 */
export declare const resolveHighlightLines: (info: string) => HighlightLinesRange[] | null;
/**
 * Check if a line number is in ranges
 */
export declare const isHighlightLine: (lineNumber: number, ranges: HighlightLinesRange[]) => boolean;
