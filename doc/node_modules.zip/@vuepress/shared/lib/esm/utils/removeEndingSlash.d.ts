/**
 * Remove ending slash / from a string
 */
export declare const removeEndingSlash: (str: string) => string;
