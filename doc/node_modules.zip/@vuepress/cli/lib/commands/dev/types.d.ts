/**
 * Type of `dev` command function
 */
export declare type DevCommand = (sourceDir?: string, commandOptions?: DevCommandOptions) => Promise<void>;
/**
 * CLI options of `dev` command
 */
export interface DevCommandOptions {
    port?: number;
    host?: string;
    temp?: string;
    cache?: string;
    debug?: boolean;
    open?: boolean;
    config?: string;
    cleanTemp?: boolean;
    cleanCache?: boolean;
    watch?: boolean;
}
