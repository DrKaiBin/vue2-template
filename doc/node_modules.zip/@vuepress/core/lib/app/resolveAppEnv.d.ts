import type { AppEnv, AppOptions } from '../types';
/**
 * Resolve environment flags for vuepress app
 */
export declare const resolveAppEnv: (options: AppOptions, isBuild: boolean) => AppEnv;
