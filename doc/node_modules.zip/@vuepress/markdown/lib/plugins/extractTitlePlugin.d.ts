import type { PluginSimple } from 'markdown-it';
/**
 * Extracting markdown title to env
 */
export declare const extractTitlePlugin: PluginSimple;
