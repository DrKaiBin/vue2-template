import type { Plugin } from '@vuepress/core';
export declare type BackToTopPluginOptions = Record<never, never>;
export declare const backToTopPlugin: Plugin<BackToTopPluginOptions>;
