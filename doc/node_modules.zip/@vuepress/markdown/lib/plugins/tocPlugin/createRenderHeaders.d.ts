import type { MarkdownHeader } from '../../types';
import type { TocPluginOptions } from './tocPlugin';
declare type RenderHeadersFn = (headers: MarkdownHeader[]) => string;
export declare const createRenderHeaders: ({ listTag, listClass, itemClass, linkTag, linkClass, }: Pick<Required<TocPluginOptions>, 'listTag' | 'listClass' | 'itemClass' | 'linkTag' | 'linkClass'>) => RenderHeadersFn;
export {};
