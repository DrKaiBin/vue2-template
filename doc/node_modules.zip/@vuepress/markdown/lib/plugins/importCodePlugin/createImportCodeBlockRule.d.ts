import type { RuleBlock } from 'markdown-it/lib/parser_block';
import type { ImportCodePluginOptions } from './importCodePlugin';
export declare const createImportCodeBlockRule: ({ handleImportPath }: ImportCodePluginOptions) => RuleBlock;
