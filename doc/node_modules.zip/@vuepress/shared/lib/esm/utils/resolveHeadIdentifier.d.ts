import type { HeadConfig } from '../types';
/**
 * Resolve identifier of a tag, to avoid duplicated tags in `<head>`
 */
export declare const resolveHeadIdentifier: ([tag, attrs, content,]: HeadConfig) => string;
