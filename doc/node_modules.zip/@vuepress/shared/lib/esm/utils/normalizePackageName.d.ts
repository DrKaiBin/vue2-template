/**
 * Normalize package name
 */
export declare const normalizePackageName: (request: string, org: string, type?: string | null) => string;
