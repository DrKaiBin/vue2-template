export declare const getScrollTop: () => number;
