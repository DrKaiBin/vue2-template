import type { App } from '@vuepress/core';
import type { Plugin } from 'vite';
/**
 * Global constants and env variables will be statically replaced in
 * production mode, even in JavaScript string and Vue template.
 *
 * To avoid that behavior, we use this plugin to insert `'\u200b'` char into
 * constant strings in page data, and insert `<wbr>` tag into constant strings
 * in template of page component.
 *
 * @see https://vitejs.dev/guide/env-and-mode.html#production-replacement
 */
export declare const createConstantsReplacementPlugin: (app: App) => Plugin;
