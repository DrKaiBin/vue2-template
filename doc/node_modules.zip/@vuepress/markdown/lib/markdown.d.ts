import type { Markdown, MarkdownOptions } from './types';
/**
 * Create vuepress customized markdown-it instance
 */
export declare const createMarkdown: ({ anchor, assets, code, customComponent, emoji, extractHeaders, extractTitle, hoistTags, importCode, links, toc, ...markdownItOptions }?: MarkdownOptions) => Markdown;
