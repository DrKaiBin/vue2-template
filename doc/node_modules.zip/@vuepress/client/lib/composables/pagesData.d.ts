import type { PageData } from '@vuepress/shared';
import type { Ref } from 'vue';
/**
 * Data resolvers of all pages
 *
 * The key is page key, and the value is an async function that
 * returns the page data
 */
export declare type PagesData = Record<string, (() => Promise<PageData>) | undefined>;
/**
 * Ref wrapper of `PagesData`
 */
export declare type PagesDataRef = Ref<PagesData>;
/**
 * Global pages data ref
 */
export declare const pagesData: PagesDataRef;
/**
 * Returns the ref of data resolvers of all pages
 */
export declare const usePagesData: () => PagesDataRef;
