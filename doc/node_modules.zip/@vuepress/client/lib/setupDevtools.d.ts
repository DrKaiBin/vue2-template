import type { App } from 'vue';
import type { GlobalComputed } from './setupGlobalComputed';
export declare const setupDevtools: (app: App, globalComputed: GlobalComputed) => void;
