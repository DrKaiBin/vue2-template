/**
 * Transform a ts file to cjs code
 */
export declare const transformTsFileToCodeSync: (filename: string) => string;
