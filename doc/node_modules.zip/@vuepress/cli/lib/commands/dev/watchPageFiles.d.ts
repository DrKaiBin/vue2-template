import type { App } from '@vuepress/core';
import type { FSWatcher } from 'chokidar';
/**
 * Watch page files and deps, return file watchers
 */
export declare const watchPageFiles: (app: App) => FSWatcher[];
