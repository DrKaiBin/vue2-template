import type { App, Page } from '../types';
/**
 * Resolve pages for vuepress app
 */
export declare const resolveAppPages: (app: App) => Promise<Page[]>;
