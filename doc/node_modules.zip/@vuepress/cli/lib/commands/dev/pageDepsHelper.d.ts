import type { Page } from '@vuepress/core';
/**
 * Page deps helper
 */
export interface PageDepsHelper {
    /**
     * Handle deps when adding a page
     */
    add: (page: Page) => string[];
    /**
     * Handle deps when removing a page
     */
    remove: (page: Page) => string[];
    /**
     * Get all pages that depend on the `dep`
     */
    get: (dep: string) => string[];
}
/**
 * Create page deps helper
 */
export declare const createPageDepsHelper: () => PageDepsHelper;
