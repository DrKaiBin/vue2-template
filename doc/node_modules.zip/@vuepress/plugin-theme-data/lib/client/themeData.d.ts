import type { ThemeData } from '../shared'

declare module '@internal/themeData' {
  export const themeData: ThemeData
}
