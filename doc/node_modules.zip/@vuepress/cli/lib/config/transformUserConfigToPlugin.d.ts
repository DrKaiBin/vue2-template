import type { App, PluginObject } from '@vuepress/core';
import type { UserConfig } from './types';
/**
 * Transform user config to a vuepress plugin
 */
export declare const transformUserConfigToPlugin: (app: App, userConfig: UserConfig) => PluginObject;
