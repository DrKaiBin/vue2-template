import type { App } from 'vue';
import type { Router } from 'vue-router';
export declare type CreateVueAppFunction = () => Promise<{
    app: App;
    router: Router;
}>;
export declare const createVueApp: CreateVueAppFunction;
