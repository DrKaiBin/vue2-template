import type { Plugin } from '@vuepress/core';
import type { ExternalLinkIconLocales } from '../shared';
/**
 * Options for @vuepress/plugin-external-link-icon
 */
export declare type ExternalLinkIconPluginOptions = {
    locales?: ExternalLinkIconLocales;
};
export declare const externalLinkIconPlugin: Plugin<ExternalLinkIconPluginOptions>;
