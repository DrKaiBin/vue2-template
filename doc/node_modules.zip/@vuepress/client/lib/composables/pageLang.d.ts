import type { ComputedRef, InjectionKey } from 'vue';
/**
 * Page language
 */
export declare type PageLang = string;
/**
 * Ref wrapper of `PageLang`
 */
export declare type PageLangRef = ComputedRef<PageLang>;
/**
 * Injection key for page language
 */
export declare const pageLangSymbol: InjectionKey<PageLangRef>;
/**
 * Returns the ref of the language of current page
 */
export declare const usePageLang: () => PageLangRef;
