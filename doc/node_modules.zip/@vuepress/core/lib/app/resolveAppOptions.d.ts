import type { AppConfig, AppOptions } from '../types';
/**
 * Create app options with default values
 */
export declare const resolveAppOptions: ({ base, lang, title, description, head, locales, theme, themeConfig, bundler, bundlerConfig, source, dest, temp, cache, public: publicDir, markdown, host, port, debug, open, pagePatterns, templateDev, templateBuild, shouldPreload, shouldPrefetch, plugins, }: AppConfig) => AppOptions;
