import type { App } from 'vue';
/**
 * Register global built-in components
 */
export declare const setupGlobalComponents: (app: App) => void;
