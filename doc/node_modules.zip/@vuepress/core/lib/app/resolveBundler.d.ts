import type { AppOptions, Bundler } from '../types';
export declare const resolveBundler: ({ bundler, bundlerConfig, }: AppOptions) => Bundler;
