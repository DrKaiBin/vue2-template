import type { ComputedRef, InjectionKey } from 'vue';
/**
 * Page head title, which would be used as the content of `head > title` tag
 */
export declare type PageHeadTitle = string;
/**
 * Ref wrapper of `PageHeadTitle`
 */
export declare type PageHeadTitleRef = ComputedRef<PageHeadTitle>;
/**
 * Injection key for page head title
 */
export declare const pageHeadTitleSymbol: InjectionKey<PageHeadTitleRef>;
/**
 * Returns the ref of the head title of current page
 */
export declare const usePageHeadTitle: () => PageHeadTitleRef;
