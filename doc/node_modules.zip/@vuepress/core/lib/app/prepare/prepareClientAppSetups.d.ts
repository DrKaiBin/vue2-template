import type { App } from '../../types';
/**
 * Generate client app setups temp file
 */
export declare const prepareClientAppSetups: (app: App) => Promise<void>;
