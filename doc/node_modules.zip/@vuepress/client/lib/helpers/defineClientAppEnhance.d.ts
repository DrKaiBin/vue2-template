import type { ClientAppEnhance } from '../types';
export declare const defineClientAppEnhance: (clientAppEnhance: ClientAppEnhance) => ClientAppEnhance;
