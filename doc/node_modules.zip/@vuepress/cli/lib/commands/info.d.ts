export declare const info: () => Promise<void>;
