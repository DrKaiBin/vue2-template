import type { ComputedRef, InjectionKey } from 'vue';
/**
 * Route locale path
 */
export declare type RouteLocale = string;
/**
 * Ref wrapper of `RouteLocale`
 */
export declare type RouteLocaleRef = ComputedRef<RouteLocale>;
/**
 * Injection key for page route locale path
 */
export declare const routeLocaleSymbol: InjectionKey<RouteLocaleRef>;
/**
 * Returns the ref of the route locale path of current page
 */
export declare const useRouteLocale: () => RouteLocaleRef;
