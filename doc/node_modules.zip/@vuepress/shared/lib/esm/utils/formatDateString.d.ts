/**
 * Format a date string to `yyyy-MM-dd`
 */
export declare const formatDateString: (str: string, defaultDateString?: string) => string;
