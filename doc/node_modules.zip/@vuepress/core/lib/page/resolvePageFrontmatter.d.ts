import type { PageFrontmatter, PageOptions } from '../types';
/**
 * Resolve page frontmatter from user frontmatter and options frontmatter
 */
export declare const resolvePageFrontmatter: ({ frontmatterRaw, options, }: {
    frontmatterRaw: PageFrontmatter;
    options: PageOptions;
}) => PageFrontmatter;
