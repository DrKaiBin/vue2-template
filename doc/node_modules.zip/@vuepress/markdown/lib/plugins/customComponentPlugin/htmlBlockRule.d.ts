import type { RuleBlock } from 'markdown-it/lib/parser_block';
export declare const htmlBlockRule: RuleBlock;
