/**
 * Resolve the `:v-pre` / `:no-v-pre` mark from token info
 */
export declare const resolveVPre: (info: string) => boolean | null;
