import { backToTopPlugin } from './backToTopPlugin';
export * from './backToTopPlugin';
export default backToTopPlugin;
