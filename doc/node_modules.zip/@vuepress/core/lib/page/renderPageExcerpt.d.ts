import type { App, PageFrontmatter } from '../types';
/**
 * Render page excerpt from raw excerpt
 */
export declare const renderPageExcerpt: ({ app, excerptRaw, frontmatter, filePath, filePathRelative, }: {
    app: App;
    excerptRaw: string;
    frontmatter: PageFrontmatter;
    filePath: string | null;
    filePathRelative: string | null;
}) => string;
