import type { AppOptions, SiteData } from '../types';
/**
 * Resolve site data for vuepress app
 *
 * Site data will also be used in client
 */
export declare const resolveAppSiteData: (options: AppOptions) => SiteData;
