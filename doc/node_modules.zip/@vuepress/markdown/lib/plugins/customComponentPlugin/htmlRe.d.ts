export declare const HTML_TAG_RE: RegExp;
export declare const HTML_OPEN_CLOSE_TAG_RE: RegExp;
