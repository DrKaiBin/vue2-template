import type { Plugin } from '@vuepress/core';
export declare type NprogressPluginOptions = Record<never, never>;
export declare const nprogressPlugin: Plugin<NprogressPluginOptions>;
