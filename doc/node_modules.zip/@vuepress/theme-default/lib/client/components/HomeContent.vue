<template>
  <div class="theme-default-content custom">
    <Content />
  </div>
</template>
