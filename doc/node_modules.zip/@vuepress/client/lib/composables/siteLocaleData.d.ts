import type { SiteData } from '@vuepress/shared';
import type { ComputedRef, InjectionKey } from 'vue';
/**
 * Site data of current locale
 */
export declare type SiteLocaleData = SiteData;
/**
 * Ref wrapper of `SiteLocaleData`
 */
export declare type SiteLocaleDataRef = ComputedRef<SiteLocaleData>;
/**
 * Injection key for site locale data
 */
export declare const siteLocaleDataSymbol: InjectionKey<SiteLocaleDataRef>;
/**
 * Returns the ref of the site data of current locale
 */
export declare const useSiteLocaleData: () => SiteLocaleDataRef;
