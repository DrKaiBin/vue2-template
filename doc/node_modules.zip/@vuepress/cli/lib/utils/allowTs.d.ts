/**
 * Globally allow ts files to be loaded via `require()`
 */
export declare const allowTs: () => void;
