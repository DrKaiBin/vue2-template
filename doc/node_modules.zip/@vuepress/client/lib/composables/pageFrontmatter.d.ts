import type { PageFrontmatter } from '@vuepress/shared';
import type { ComputedRef, InjectionKey } from 'vue';
export type { PageFrontmatter };
/**
 * Ref wrapper of `PageFrontmatter`
 */
export declare type PageFrontmatterRef<T extends Record<any, any> = Record<string, unknown>> = ComputedRef<PageFrontmatter<T>>;
/**
 * Injection key for page frontmatter
 */
export declare const pageFrontmatterSymbol: InjectionKey<PageFrontmatterRef>;
/**
 * Returns the ref of the frontmatter of current page
 */
export declare const usePageFrontmatter: <T extends Record<any, any> = Record<string, unknown>>() => PageFrontmatterRef<T>;
