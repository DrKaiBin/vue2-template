import type { HeadConfig } from '@vuepress/shared';
/**
 * Auto update head and provide as global util
 */
export declare const setupUpdateHead: () => void;
/**
 * Query the matched head tag of head config
 */
export declare const queryHeadTag: ([tagName, attrs, content,]: HeadConfig) => HTMLElement | null;
/**
 * Create head tag from head config
 */
export declare const createHeadTag: ([tagName, attrs, content,]: HeadConfig) => HTMLElement | null;
