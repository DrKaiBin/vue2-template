/**
 * Determine a link is a tel: address or not
 */
export declare const isLinkTel: (link: string) => boolean;
