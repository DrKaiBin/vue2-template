import type { AppDir, AppWriteTemp } from '../types';
/**
 * Resolve write temp file util for vuepress app
 */
export declare const resolveAppWriteTemp: (dir: AppDir) => AppWriteTemp;
