import type { App, Page } from '@vuepress/core';
/**
 * Event handler for page unlink event
 *
 * Returns the removed page
 */
export declare const handlePageUnlink: (app: App, filePath: string) => Promise<Page | null>;
