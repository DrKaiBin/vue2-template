import type { PageOptions } from '../types';
/**
 * Resolve page file content according to filePath or options content
 */
export declare const resolvePageFileContent: ({ filePath, options, }: {
    filePath: string | null;
    options: PageOptions;
}) => Promise<string>;
