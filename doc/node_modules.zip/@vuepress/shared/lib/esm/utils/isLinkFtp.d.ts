/**
 * Determine a link is ftp link or not
 */
export declare const isLinkFtp: (link: string) => boolean;
