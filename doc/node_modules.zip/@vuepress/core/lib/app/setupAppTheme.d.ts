import type { App, AppConfig } from '../types';
/**
 * Setup theme for vuepress app
 */
export declare const setupAppTheme: (app: App, config: AppConfig) => void;
