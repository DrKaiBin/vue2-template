import type { PageData, PageFrontmatter, PageHead, PageHeadTitle, PageLang, RouteLocale, SiteData, SiteLocaleData } from './composables';
/**
 * Resolver methods to get global computed
 *
 * Users can override corresponding method for advanced customization
 */
export declare const resolvers: {
    resolvePageData: (pageKey: string) => Promise<PageData>;
    resolvePageFrontmatter: (pageData: PageData) => PageFrontmatter;
    resolvePageHead: (headTitle: PageHeadTitle, frontmatter: PageFrontmatter, siteLocale: SiteLocaleData) => PageHead;
    resolvePageHeadTitle: (page: PageData, siteLocale: SiteLocaleData) => PageHeadTitle;
    resolvePageLang: (pageData: PageData) => PageLang;
    resolveRouteLocale: (locales: SiteData['locales'], routePath: string) => RouteLocale;
    resolveSiteLocaleData: (site: SiteData, routeLocale: RouteLocale) => SiteLocaleData;
};
