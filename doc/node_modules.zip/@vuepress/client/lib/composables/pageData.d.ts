import type { PageData } from '@vuepress/shared';
import type { Ref } from 'vue';
export type { PageData };
/**
 * Ref wrapper of `PageData`
 */
export declare type PageDataRef<T extends Record<any, any> = Record<never, never>> = Ref<PageData<T>>;
/**
 * Empty page data to be used as the fallback value
 */
export declare const pageDataEmpty: PageData<Record<never, never>>;
/**
 * Global page data ref
 */
export declare const pageData: PageDataRef;
/**
 * Returns the ref of the data of current page
 */
export declare const usePageData: <T extends Record<any, any> = Record<never, never>>() => PageDataRef<T>;
