/**
 * Resolve relative and absolute paths according to the `base` and `filePathRelative`
 */
export declare const resolvePaths: (rawPath: string, base: string, filePathRelative: string | null) => {
    absolutePath: string;
    relativePath: string;
};
