import type { AppConfig } from '@vuepress/core';
import type { DevCommand } from './types';
export declare const createDev: (defaultAppConfig: Partial<AppConfig>) => DevCommand;
