import type { AppConfig } from '@vuepress/core';
/**
 * Resolve app config according to command options of cli
 */
export declare const resolveAppConfigFromCommandOptions: (sourceDir: string, commandOptions: Partial<AppConfig>, cwd?: string) => AppConfig;
