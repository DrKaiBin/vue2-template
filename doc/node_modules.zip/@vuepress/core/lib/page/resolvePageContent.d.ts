import type { PageFrontmatter } from '../types';
/**
 * Resolve page content and raw frontmatter & excerpt
 */
export declare const resolvePageContent: ({ contentRaw, }: {
    contentRaw: string;
}) => {
    content: string;
    frontmatterRaw: PageFrontmatter;
    excerptRaw: string;
};
