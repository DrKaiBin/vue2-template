import { activeHeaderLinksPlugin } from './activeHeaderLinksPlugin';
export * from './activeHeaderLinksPlugin';
export default activeHeaderLinksPlugin;
