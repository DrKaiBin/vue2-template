import type { App } from '../../types';
/**
 * Generate client app root components temp file
 */
export declare const prepareClientAppRootComponents: (app: App) => Promise<void>;
