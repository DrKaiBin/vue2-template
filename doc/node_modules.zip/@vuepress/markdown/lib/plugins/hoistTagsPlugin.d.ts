import type { PluginWithOptions } from 'markdown-it';
export interface HoistTagsPluginOptions {
    customBlocks?: string[];
}
/**
 * Avoid rendering vue SFC script / style blocks
 *
 * Extract them into env
 *
 * Hoist them to vue SFC root level in following process
 */
export declare const hoistTagsPlugin: PluginWithOptions<HoistTagsPluginOptions>;
