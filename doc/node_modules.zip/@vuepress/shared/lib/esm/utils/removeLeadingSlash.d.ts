/**
 * Remove leading slash / from a string
 */
export declare const removeLeadingSlash: (str: string) => string;
