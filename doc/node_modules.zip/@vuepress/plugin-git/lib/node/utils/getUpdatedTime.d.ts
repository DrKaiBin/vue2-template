/**
 * Get unix timestamp in milliseconds of the last commit
 */
export declare const getUpdatedTime: (filePath: string, cwd: string) => Promise<number>;
