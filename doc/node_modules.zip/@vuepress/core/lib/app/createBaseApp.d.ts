import type { App, AppConfig } from '../types';
/**
 * Create vuepress app
 */
export declare const createBaseApp: (config: AppConfig, isBuild?: boolean) => App;
