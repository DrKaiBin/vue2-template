/**
 * Get unix timestamp in milliseconds of the first commit
 */
export declare const getCreatedTime: (filePath: string, cwd: string) => Promise<number>;
