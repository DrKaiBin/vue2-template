import type { SiteData } from '@vuepress/shared'

declare module '@internal/siteData' {
  export const siteData: SiteData
}
