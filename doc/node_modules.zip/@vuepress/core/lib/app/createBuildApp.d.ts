import type { AppConfig, BuildApp } from '../types';
/**
 * Create vuepress build app
 */
export declare const createBuildApp: (config: AppConfig) => BuildApp;
