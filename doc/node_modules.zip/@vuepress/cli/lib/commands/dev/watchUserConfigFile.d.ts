import type { FSWatcher } from 'chokidar';
export declare const watchUserConfigFile: ({ userConfigPath, userConfigDeps, restart, }: {
    userConfigPath: string;
    userConfigDeps: string[];
    restart: () => Promise<void>;
}) => FSWatcher[];
