import type { InjectionKey } from 'vue';
/**
 * A util function to force update `<head>` of current page
 */
export declare type UpdateHead = () => void;
/**
 * Injection key for `updateHead` util
 */
export declare const updateHeadSymbol: InjectionKey<UpdateHead>;
/**
 * Returns the `updateHead` util
 */
export declare const useUpdateHead: () => UpdateHead;
