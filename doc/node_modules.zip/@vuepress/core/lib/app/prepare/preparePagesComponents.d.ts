import type { App } from '../../types';
/**
 * Generate page key to page component map temp file
 */
export declare const preparePagesComponents: (app: App) => Promise<void>;
