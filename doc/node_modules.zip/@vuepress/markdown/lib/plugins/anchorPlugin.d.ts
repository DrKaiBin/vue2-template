import anchorPlugin from 'markdown-it-anchor';
export declare type AnchorPluginOptions = anchorPlugin.AnchorOptions;
export { anchorPlugin };
