import type { App, Page, PageOptions } from '../types';
export declare const createPage: (app: App, options: PageOptions) => Promise<Page>;
