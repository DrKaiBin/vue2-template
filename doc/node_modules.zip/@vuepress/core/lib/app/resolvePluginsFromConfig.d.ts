import type { App, PluginConfig, PluginObject } from '../types';
/**
 * Resolve plugin objects from plugin config array
 */
export declare const resolvePluginsFromConfig: (app: App, plugins?: PluginConfig[]) => PluginObject[];
