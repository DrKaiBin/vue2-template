import type { RuleInline } from 'markdown-it/lib/parser_inline';
export declare const htmlInlineRule: RuleInline;
