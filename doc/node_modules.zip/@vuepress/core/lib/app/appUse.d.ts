import type { App, Plugin, PluginOptions } from '../types';
export declare const appUse: <T extends PluginOptions>(app: App, rawPlugin: string | Plugin<T, import("../types").PluginObject>, config?: Partial<T> | undefined) => App;
