import type { PluginWithOptions } from 'markdown-it';
export interface CodePluginOptions {
    /**
     * Enable highlight lines or not
     */
    highlightLines?: boolean;
    /**
     * Enable line numbers or not
     *
     * - A `boolean` value is to enable line numbers or not.
     * - A `number` value is the minimum number of lines to enable line numbers
     */
    lineNumbers?: boolean | number;
    /**
     * Wrap the `<pre>` tag with an extra `<div>` or not. Do not disable it unless you
     * understand what's it for
     *
     * - Required for `highlightLines`
     * - Required for `lineNumbers`
     * - Required for language display of default theme
     */
    preWrapper?: boolean;
    /**
     * Add `v-pre` directive to `<pre>` tag or not
     */
    vPre?: boolean;
}
/**
 * Code plugin
 */
export declare const codePlugin: PluginWithOptions<CodePluginOptions>;
