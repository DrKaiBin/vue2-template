import type { Plugin } from 'vite';
/**
 * Vite will inject version hash into file queries, which does not work
 * well with VuePress.
 *
 * As a workaround, we remove the version hash to avoid the injection.
 */
export declare const createWorkaroundPlugin: () => Plugin;
