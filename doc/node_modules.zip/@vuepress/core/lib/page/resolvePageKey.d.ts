/**
 * Resolve page key to identify the page
 */
export declare const resolvePageKey: ({ path }: {
    path: string;
}) => string;
