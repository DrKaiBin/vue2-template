import type { App, Page } from '@vuepress/core';
/**
 * Event handler for page change event
 *
 * Returns the old page and the new page tuple
 */
export declare const handlePageChange: (app: App, filePath: string) => Promise<[Page, Page] | null>;
