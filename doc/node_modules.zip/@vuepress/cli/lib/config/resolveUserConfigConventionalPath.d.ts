/**
 * Resolve conventional user config file path
 */
export declare const resolveUserConfigConventionalPath: (source: string, cwd?: string) => string | undefined;
