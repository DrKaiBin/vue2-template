import type { App } from '../../types';
/**
 * Generate page path to page data map temp file
 */
export declare const preparePagesData: (app: App) => Promise<void>;
