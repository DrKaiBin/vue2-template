/**
 * Escape html chars
 */
export declare const htmlEscape: (str: string) => string;
