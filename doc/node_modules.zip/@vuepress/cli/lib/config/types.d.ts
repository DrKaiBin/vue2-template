import type { AppConfig, BundlerConfig, PluginObject, ThemeConfig } from '@vuepress/core';
/**
 * User config type of vuepress
 *
 * It will be transformed to `AppConfig` by cli
 */
export declare type UserConfig<T extends ThemeConfig = ThemeConfig, U extends BundlerConfig = BundlerConfig> = Partial<AppConfig<T, U>> & Omit<PluginObject, 'name' | 'multiple'>;
export declare type UserConfigLoader = (userConfigPath: string) => Promise<UserConfig>;
