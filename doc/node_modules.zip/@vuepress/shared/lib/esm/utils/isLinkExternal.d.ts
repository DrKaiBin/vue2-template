/**
 * Determine a link is external or not
 */
export declare const isLinkExternal: (link: string, base?: string) => boolean;
