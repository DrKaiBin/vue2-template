import type { Router } from 'vue-router';
/**
 * Create vue-router instance
 */
export declare const createVueRouter: () => Router;
