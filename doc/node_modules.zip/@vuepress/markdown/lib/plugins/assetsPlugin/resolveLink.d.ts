import type { MarkdownEnv } from '../../types';
export declare const resolveLink: (link: string, relativePathPrefix: string, env: MarkdownEnv) => string;
