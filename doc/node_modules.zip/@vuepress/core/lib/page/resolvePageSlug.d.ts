/**
 * Resolve page slug from filename
 */
export declare const resolvePageSlug: ({ filePathRelative, }: {
    filePathRelative: string | null;
}) => string;
