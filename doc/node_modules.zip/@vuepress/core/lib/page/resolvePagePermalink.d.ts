import type { PageFrontmatter } from '../types';
/**
 * Resolve page permalink from frontmatter / options / pattern
 */
export declare const resolvePagePermalink: ({ frontmatter, slug, date, pathInferred, pathLocale, }: {
    frontmatter: PageFrontmatter;
    slug: string;
    date: string;
    pathInferred: string | null;
    pathLocale: string;
}) => string | null;
