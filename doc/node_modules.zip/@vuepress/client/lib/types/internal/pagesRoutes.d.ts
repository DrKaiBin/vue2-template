import type { RouteRecordRaw } from 'vue-router'

declare module '@internal/pagesRoutes' {
  export const pagesRoutes: RouteRecordRaw[]
}
