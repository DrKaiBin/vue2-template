import type { App, PageOptions } from '../types';
/**
 * Resolve absolute and relative path of page file
 */
export declare const resolvePageFilePath: ({ app, options, }: {
    app: App;
    options: PageOptions;
}) => {
    filePath: string | null;
    filePathRelative: string | null;
};
