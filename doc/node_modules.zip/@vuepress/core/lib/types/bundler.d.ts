import type { App } from './app';
/**
 * Vuepress bundler
 *
 * It provides abilities to:
 * - dev: run dev server for development
 * - build: bundle assets for deployment
 */
export interface Bundler {
    dev: BundlerDev;
    build: BundlerBuild;
}
export declare type BundlerDev = (app: App) => Promise<() => Promise<void>>;
export declare type BundlerBuild = (app: App) => Promise<void>;
/**
 * A function that returns a bundler instance
 *
 * A bundler package should have a `CreateBundlerFunction` as the default export
 */
export declare type CreateBundlerFunction<BundlerOptions extends BundlerConfig = Partial<BundlerConfig>> = (options: BundlerOptions) => Bundler;
/**
 * Bundler entry type
 */
export interface BundlerEntry {
    createBundler: CreateBundlerFunction;
}
/**
 * User config type of bundler
 *
 * @remark suffix `Config` means this is for user config
 */
export interface BundlerConfig {
    [key: string]: any;
}
