/**
 * Determine a link is http link or not
 *
 * - http://github.com
 * - https://github.com
 * - //github.com
 */
export declare const isLinkHttp: (link: string) => boolean;
