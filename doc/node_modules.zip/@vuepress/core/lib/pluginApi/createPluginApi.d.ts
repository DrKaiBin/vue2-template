import type { PluginApi } from '../types';
export declare const createPluginApi: () => PluginApi;
