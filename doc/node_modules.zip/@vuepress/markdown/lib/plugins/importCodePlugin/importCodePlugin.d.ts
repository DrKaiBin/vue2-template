import type { PluginWithOptions } from 'markdown-it';
export interface ImportCodePluginOptions {
    /**
     * A function to handle the import path
     */
    handleImportPath?: (str: string) => string;
}
export declare const importCodePlugin: PluginWithOptions<ImportCodePluginOptions>;
