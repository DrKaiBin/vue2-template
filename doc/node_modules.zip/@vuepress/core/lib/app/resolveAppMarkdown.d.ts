import type { Markdown } from '@vuepress/markdown';
import type { App } from '../types';
/**
 * Resolve markdown-it instance for vuepress app
 */
export declare const resolveAppMarkdown: (app: App) => Promise<Markdown>;
