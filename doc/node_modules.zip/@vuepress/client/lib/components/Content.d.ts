import type { FunctionalComponent } from 'vue';
/**
 * Markdown rendered content
 */
export declare const Content: FunctionalComponent<{
    pageKey?: string;
}>;
