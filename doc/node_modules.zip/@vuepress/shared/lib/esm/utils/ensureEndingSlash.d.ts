/**
 * Ensure a url string to have ending slash /
 */
export declare const ensureEndingSlash: (str: string) => string;
