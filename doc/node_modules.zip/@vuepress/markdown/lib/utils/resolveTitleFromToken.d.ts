import type * as Token from 'markdown-it/lib/token';
/**
 * Resolve header title from markdown-it token
 *
 * Typically using the next token of `heading_open` token
 */
export declare const resolveTitleFromToken: (token: Token, { allowHtml, escapeText, }: {
    allowHtml: boolean;
    escapeText: boolean;
}) => string;
