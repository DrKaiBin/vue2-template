import type { LocaleConfig } from '../types';
/**
 * Resolve the matched locale path of route path
 */
export declare const resolveLocalePath: (locales: LocaleConfig, routePath: string) => string;
