import type { PluginConfig, PluginConfigNormalized, PluginOptions } from '../types';
export declare const normalizePluginConfig: <T extends PluginOptions>(pluginConfig: PluginConfig<T>) => PluginConfigNormalized<T>;
