/**
 * Resolve file path of user config
 */
export declare const resolveUserConfigPath: (config: string, cwd?: string) => string;
