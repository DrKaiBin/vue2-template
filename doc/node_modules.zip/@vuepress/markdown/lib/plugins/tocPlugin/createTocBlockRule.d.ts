import type { RuleBlock } from 'markdown-it/lib/parser_block';
import type { TocPluginOptions } from './tocPlugin';
/**
 * Forked and modified from markdown-it-toc-done-right
 *
 * - remove the `inlineOptions` support
 * - use markdown-it default renderer to render token whenever possible
 *
 * @see https://github.com/nagaozen/markdown-it-toc-done-right
 */
export declare const createTocBlockRule: ({ pattern, containerTag, containerClass, }: Pick<Required<TocPluginOptions>, 'pattern' | 'containerTag' | 'containerClass'>) => RuleBlock;
