import type { App } from '@vuepress/core';
import type { Plugin } from 'vite';
import type { ViteBundlerOptions } from '../types';
export declare const createPlugins: ({ app, options, isServer, isBuild, }: {
    app: App;
    options: ViteBundlerOptions;
    isServer: boolean;
    isBuild: boolean;
}) => Plugin[];
