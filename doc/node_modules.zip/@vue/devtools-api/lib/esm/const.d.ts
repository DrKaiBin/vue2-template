export declare const HOOK_SETUP = "devtools-plugin:setup";
export declare const HOOK_PLUGIN_SETTINGS_SET = "plugin:settings:set";
